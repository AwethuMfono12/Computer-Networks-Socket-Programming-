#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Mar  1 22:57:12 2023

@author: anovuyomfono
"""

# tcp-server.py

from  socket import*
import datetime as dt
from datetime import datetime, timedelta
import requests

timeDiff = {
   "Rome" : 1,
    "Milan" : 1,
   "Naples" : 1,
    "kabul" : 2,
    "Kanahar" : 2,
    "Herat" : 2,
    "Vienna" : 1,
    "Graz" : 1,
    "Linz" : 1,
    "Luanda" : 1,
    " Huambo" : 1 ,
    "Lubango" : 1,
    "Sydney": 9,
    "Melbourne" : 9,
    "Brisbane" : 8,
    "Brussel" : 1,
    "Antwerp" : 1,
    "Gent"
    "Sao Paulo" : 5,
    "Rio de Janeiro" : 5,
    "London" : 5,
    "Mexico City ": 9,
    "New York": 9,
    "Tokyo" : 2,
    "Beijing": 2,
    "Paris " : 2,
    "Madrid" : 1,
   " Taipei City" : 1,
   " Bangkok" : 1,
  
   }

# create the socket
# AF_INET == ipv4
# AF_INET6 == ipv6
# SOCK_STREAM == TCP
serverPort = 8080
serverSocket = socket(AF_INET,SOCK_STREAM)

#bind a socket to some port on the server

serverSocket.bind(("",serverPort))
serverSocket.listen(5)
print ("The server is ready to receive")


    
while True:
     connectionSocket, addr = serverSocket.accept()
     user_time = connectionSocket.recv(1024).decode()
   
    dt_instances = datetime.strptime(userdate, '%Y-%m-%d %H:%M:%S')
    time_change = timedelta(hours=timeDiff[user_city])
    sa_time = user_time + time_change
    time_sa_str = time_sa.strft('%Y-%m-d %H:M')
     
    
     connectionSocket.send(time_sa_str.encode())
     connectionsocket.close()

     

  

     
     
    
    

