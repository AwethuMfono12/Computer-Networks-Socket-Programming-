#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Mar  3 12:59:44 2023

@author: anovuyomfono
"""

import datetime as dt
import datetime as dt

user_city = input("please enter city you stay in")
user_time = int(input("please enter time of meeting")

if user_city == "lol" 
    time_change = dt.timedelta(minutes=30)
    new_time = user_time + time_change
print(new_time)
      

    
    
