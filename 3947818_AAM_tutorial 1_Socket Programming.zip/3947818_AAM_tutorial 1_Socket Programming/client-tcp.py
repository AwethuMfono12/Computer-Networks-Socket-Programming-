#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Mar  1 22:53:45 2023

@author: anovuyomfono
"""

# tcp-client.py

from socket import *

serverName = "127.1.1.0"
serverPort = 8080
clientSocket = socket(AF_INET, SOCK_STREAM)
clientSocket.connect(("",serverPort))


user_date = input("please indicate the date you would like your meeting in format YYYY-MM-DD ")
user_time = input("please indicate the time you would like your meeting in format  HH-MM-SS ")

print("""please indicate the city you live in pick a number that corresponds to city:
                 1. Rome
                 2. Milan
                 3. Naples
                 4. kabul 
                 5. Kanahar
                 6. Herat
                 7. Vienna
                 8. Graz
                 9. Linz
                 10. Luanda
                 11. Huambo
                 12. Lubango
                 13. Sydney
                 14. Melbourne
                 15. Brisbane
                 16. Brussel
                 17. Antwerp
                 18. Gent
                 19. Sao Paulo
                 20. Rio de Janeiro
                 21. London
                 22. Mexico City 
                 23. New York
                 24. Tokyo
                 25. Beijing
                 26. Paris 
                 27. Madrid
                 28. Taipei City
                 29. Bangkok""")                                                                                     

user_city = input("please enter your city: ").capitalize()

user_topic = input("please indicate the topic meeting is based on ")
user_platform = input("please indicate the platform of meeting")


#text = raw_input("Enter a Letter: ").lower() print text

clientSocket.send(user_time.encode())
modifiedtime_sa = clientSocket.recv(1024)
print ("meeting will be held at ", modifiedtime_sa_str.decode())
clientSocket.close()


